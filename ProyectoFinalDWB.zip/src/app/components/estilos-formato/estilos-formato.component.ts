import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estilos-formato',
  templateUrl: './estilos-formato.component.html',
  styleUrls: ['./estilos-formato.component.css']
})
export class EstilosFormatoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
