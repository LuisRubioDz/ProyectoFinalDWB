import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otr-elementos',
  templateUrl: './otr-elementos.component.html',
  styleUrls: ['./otr-elementos.component.css']
})
export class OtrElementosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
