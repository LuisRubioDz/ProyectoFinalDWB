import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lobasico',
  templateUrl: './lobasico.component.html',
  styleUrls: ['./lobasico.component.css']
})
export class LobasicoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
