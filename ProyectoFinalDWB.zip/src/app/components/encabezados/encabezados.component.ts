import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-encabezados',
  templateUrl: './encabezados.component.html',
  styleUrls: ['./encabezados.component.css']
})
export class EncabezadosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
