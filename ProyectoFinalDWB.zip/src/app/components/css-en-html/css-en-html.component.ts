import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-css-en-html',
  templateUrl: './css-en-html.component.html',
  styleUrls: ['./css-en-html.component.css']
})
export class CssEnHtmlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
