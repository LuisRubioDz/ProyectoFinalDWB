import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-links-imgs',
  templateUrl: './links-imgs.component.html',
  styleUrls: ['./links-imgs.component.css']
})
export class LinksImgsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
